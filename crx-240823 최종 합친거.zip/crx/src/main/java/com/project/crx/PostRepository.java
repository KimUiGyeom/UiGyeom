package com.project.crx;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface PostRepository extends JpaRepository<PostVO, Long> {
    // JPA에서 기본으로 제공되는 메소드는 선언없이 사용 가능하다.
}