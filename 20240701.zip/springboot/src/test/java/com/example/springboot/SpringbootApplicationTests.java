package com.example.springboot;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.example.springboot.question.Question;
import com.example.springboot.question.QuestionRepository;

@SpringBootTest
class SpringbootApplicationTests {

	@Autowired
	private QuestionRepository questionRepository;

	@Test
	void testJpa() {
		List<Question> qList = this.questionRepository.findBysubjectLike("su%");
		Question q = qList.get(0);
		assertEquals("subject", q.getSubject());
	}

}