package com.project.crx;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;
import jakarta.persistence.Id;

@Entity
@Getter
@Setter
@ToString
@NoArgsConstructor // Lombok을 사용할 때 기본 생성자를 자동 생성
public class User {

	@Column(name = "userid")
	private int userid;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "usermail", unique = true)
	private String usermail;

	private String username;
	private String usergender;
	private String userbirth;
	private String usertel;
	private String userpwd;

	@Column(name = "status")
	private String status;

	public User(String usermail, String username, String usergender, String userbirth, String usertel, String userpwd,
			String status) {
		this.usermail = usermail;
		this.username = username;
		this.usergender = usergender;
		this.userbirth = userbirth;
		this.usertel = usertel;
		this.userpwd = userpwd;
		this.status = status;
	}
}