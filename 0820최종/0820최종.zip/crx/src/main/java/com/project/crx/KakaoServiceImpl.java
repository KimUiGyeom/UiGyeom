package com.project.crx;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

@Service
public class KakaoServiceImpl implements KakaoService {

	@Autowired
	private KakaoRepository userRepository;

	@Override
	public String getToken(String code) throws Exception {
		String accessToken = "";
		final String requestUrl = "https://kauth.kakao.com/oauth/token";

		URL url = new URL(requestUrl);
		HttpURLConnection con = (HttpURLConnection) url.openConnection();
		con.setRequestMethod("POST");
		con.setDoOutput(true);

		BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(con.getOutputStream()));
		StringBuilder sb = new StringBuilder();
		sb.append("grant_type=authorization_code");
		sb.append("&client_id=b40dbabe21f0e38eb1ca7cc8451a819c"); // 실제 클라이언트 아이디로 변경
		sb.append("&redirect_uri=http://localhost:8080/kakaologin.do");
		sb.append("&code=" + code);
		bw.write(sb.toString());
		bw.flush();

		BufferedReader br = new BufferedReader(new InputStreamReader(con.getInputStream()));
		StringBuilder resultBuilder = new StringBuilder();
		String line;

		while ((line = br.readLine()) != null) {
			resultBuilder.append(line);
		}

		JsonElement element = JsonParser.parseString(resultBuilder.toString());
		accessToken = element.getAsJsonObject().get("access_token").getAsString();

		br.close();
		bw.close();

		return accessToken;
	}

	@Override
	public ArrayList<Object> getUserInfo(String accessToken) throws Exception {
		ArrayList<Object> list = new ArrayList<>();

		final String requestUrl = "https://kapi.kakao.com/v2/user/me";
		URL url = new URL(requestUrl);
		HttpURLConnection con = (HttpURLConnection) url.openConnection();
		con.setRequestMethod("GET");
		con.setRequestProperty("Authorization", "Bearer " + accessToken);

		// 응답 처리
		StringBuilder resultBuilder = new StringBuilder();
		try (BufferedReader bf = new BufferedReader(new InputStreamReader(con.getInputStream()))) {
			String line;
			while ((line = bf.readLine()) != null) {
				resultBuilder.append(line);
			}
		}

		// JSON 응답 파싱
		JsonObject jsonObject = JsonParser.parseString(resultBuilder.toString()).getAsJsonObject();
		System.out.println("API Response: " + jsonObject.toString());

		JsonObject kakaoAccount = jsonObject.has("kakao_account") ? jsonObject.getAsJsonObject("kakao_account") : null;

		if (kakaoAccount == null) {
			throw new Exception("Invalid JSON response from Kakao API. KakaoAccount is missing.");
		}

		// 데이터 추출
		String userid = jsonObject.get("id").getAsString();
		String usermail = kakaoAccount.has("email") ? kakaoAccount.get("email").getAsString() : "not provided";
		String username = kakaoAccount.has("name") ? kakaoAccount.get("name").getAsString() : "Unknown";
		String usergender = kakaoAccount.has("gender") ? kakaoAccount.get("gender").getAsString() : "not provided";
		String userbirth = kakaoAccount.has("birthyear") ? kakaoAccount.get("birthyear").getAsString() : "not provided";
		String usertel = kakaoAccount.has("phone_number") ? kakaoAccount.get("phone_number").getAsString()
				: "not provided";

		if (usergender.equals("male")) {
			usergender = "남성";
		} else if (usergender.equals("female")) {
			usergender = "여성";
		}

		// 전화번호 +82를 0으로 변경하고 공백 제거
		if (usertel.startsWith("+82")) {
			usertel = "0" + usertel.substring(3).replace(" ", "");
		}

		list.add(usermail);
		list.add(username);
		list.add(usergender);
		list.add(userbirth);
		list.add(usertel);

		// DB에 사용자 정보 저장 또는 업데이트
		User user = userRepository.findById(usermail).orElse(null);
		if (user == null) {
			// 비밀번호가 null인 상태로 사용자 생성, status 필드에 'kakao' 설정
			user = new User(usermail, username, usergender, userbirth, usertel, null, "kakao");
			userRepository.save(user);
		} else {
			// 기존 사용자 정보를 업데이트 (필요한 경우에만)
			user.setUsername(username);
			user.setUsergender(usergender);
			user.setUserbirth(userbirth);
			user.setUsertel(usertel);

			// status 값이 없으면 'kakao'로 설정
			if (user.getStatus() == null || user.getStatus().isEmpty()) {
				user.setStatus("kakao");
			}

			userRepository.save(user); // 업데이트된 사용자 정보 저장
		}

		// User ID를 리스트에 추가
		list.add(user.getUserid());

		return list;
	}
}