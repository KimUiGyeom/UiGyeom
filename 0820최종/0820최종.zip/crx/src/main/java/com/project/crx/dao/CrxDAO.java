package com.project.crx.dao;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Repository;

import com.project.crx.vo.CrxVO;

@Mapper
@Repository("CrxDAO")
public interface CrxDAO {
	CrxVO userLogin(CrxVO crxVO) throws DataAccessException;

	CrxVO memberLogin(CrxVO crxVO) throws DataAccessException;

	CrxVO userInfo(int userid);

	CrxVO userInfoEmail(String usermail);

	void updateUserInfo(CrxVO crxVO) throws DataAccessException;

	void updateMemberInfo(CrxVO crxVO) throws DataAccessException;

	// 일반 사용자의 비밀번호 변경 메서드
	void updatePwdId(CrxVO crxVO);

	void updatePwdMem(CrxVO crxVO);

	// 카카오 로그인 사용자의 비밀번호 초기 설정 메서드
	void updatePwdMail(CrxVO crxVO);

	// 사용자 정보를 user 테이블에 삽입하는 메서드 선언
	void insertUser(CrxVO crxVO) throws DataAccessException;

	public boolean existChildUser(@Param("username") String username, @Param("parenttel") String parenttel)
			throws DataAccessException;
	
	public boolean existUser(@Param("username") String username, @Param("usertel") String usertel)
			throws DataAccessException;

}