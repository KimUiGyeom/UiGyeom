package com.project.crx.vo;

public class Pagination {
	private int page; // 현재 페이지 번호
	private int totalCount; // 전체 게시물 수
	private int pageSize = 10; // 한 페이지에 출력할 게시물 수
	private int startPage; // 시작 페이지 번호
	private int endPage; // 끝 페이지 번호
	private boolean prev; // 이전 페이지 여부
	private boolean next; // 다음 페이지 여부
	private int totalPage; // 전체 페이지 수

	public void pageInfo(int page, int totalCount) {
		this.page = page;
		this.totalCount = totalCount;

		totalPage = (int) Math.ceil((double) totalCount / pageSize);
		startPage = ((page - 1) / pageSize) * pageSize + 1;
		endPage = startPage + pageSize - 1;

		if (endPage > totalPage) {
			endPage = totalPage;
		}

		prev = startPage > 1;
		next = endPage < totalPage;
	}

	public int getPage() {
		return page;
	}

	public void setPage(int page) {
		this.page = page;
	}

	public int getTotalCount() {
		return totalCount;
	}

	public void setTotalCount(int totalCount) {
		this.totalCount = totalCount;
	}

	public int getPageSize() {
		return pageSize;
	}

	public void setPageSize(int pageSize) {
		this.pageSize = pageSize;
	}

	public int getStartPage() {
		return startPage;
	}

	public void setStartPage(int startPage) {
		this.startPage = startPage;
	}

	public int getEndPage() {
		return endPage;
	}

	public void setEndPage(int endPage) {
		this.endPage = endPage;
	}

	public boolean isPrev() {
		return prev;
	}

	public void setPrev(boolean prev) {
		this.prev = prev;
	}

	public boolean isNext() {
		return next;
	}

	public void setNext(boolean next) {
		this.next = next;
	}

	public int getTotalPage() {
		return totalPage;
	}

	public void setTotalPage(int totalPage) {
		this.totalPage = totalPage;
	}

}
