package com.project.crx.service;

import java.sql.Time;
import java.util.List;

import com.project.crx.vo.CrxScheduleVO;
import com.project.crx.vo.CrxVO;

public interface CrxService {
	CrxVO login(CrxVO crxVO) throws Exception;

	CrxVO userInfo(int userid);

	CrxVO userInfoEmail(String usermail);

	void updateUserInfo(CrxVO crxVO);

	void updateMemberInfo(CrxVO crxVO);

	// 일반 사용자의 비밀번호 변경
	void updatePwdId(CrxVO crxVO);

	void updatePwdMem(CrxVO crxVO);

	// 카카오 로그인 사용자의 비밀번호 초기 설정
	void updatePwdMail(CrxVO crxVO);

	// 회원가입 메서드 선언
	void registerUser(CrxVO crxVO) throws Exception;

	// 14세 미만 회원가입 중복 확인 메서드
	boolean existChildUser(String username, String parenttel);

	// 14세 이상 회원가입 중복 확인 메서드
	boolean existUser(String username, String usertel);

	// 회원번호 찾기 서비스 메서드
	CrxVO findUserId(CrxVO crxVO) throws Exception;

	// 비밀번호 찾기 서비스 메서드
	CrxVO findUserPwd(CrxVO crxVO) throws Exception;

	List<CrxVO> memList(String divname) throws Exception;

	void updateGrade(int userid, String level);

	List<CrxVO> mainNotice();

	void deleteUser(int userid) throws Exception;

	void updateMember(CrxVO crxVO) throws Exception;

	List<CrxScheduleVO> getCrxSchedules(String departureStation, String arrivalStation, Time departureTime);

}