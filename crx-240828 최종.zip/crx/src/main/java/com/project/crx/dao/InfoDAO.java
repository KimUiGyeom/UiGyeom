package com.project.crx.dao;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.springframework.stereotype.Repository;

@Mapper
@Repository("InfoDAO")
public interface InfoDAO {

	// 일반열차 승차권 조회
	@Select("SELECT totalCharge FROM paytrain WHERE apply_num = #{applyNum}")
    Integer getTotalCharge(@Param("applyNum") int applyNum) throws Exception;
		
	// 관광열차 승차권 조회
	@Select("SELECT coin FROM paytour WHERE apply_num = #{applyNum}")
    Integer getCoin(@Param("applyNum") String applyNum) throws Exception;
}
