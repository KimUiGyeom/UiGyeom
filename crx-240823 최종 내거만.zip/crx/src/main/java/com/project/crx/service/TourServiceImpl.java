package com.project.crx.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.project.crx.dao.TourDAO;
import com.project.crx.vo.TourVO;

@Service
public class TourServiceImpl implements TourService{

	@Autowired
	private TourDAO tourDAO;
	
    @Override
    public List<TourVO> tourList() throws Exception {
        return tourDAO.tourList();
    }
    
	@Override
	public void DeleteTour(String tournum) throws Exception {
		tourDAO.tourDelete(tournum);
	}
    
	@Override
	public void tourReserv(TourVO tourVO) throws Exception {
		tourDAO.tourReserv(tourVO);
	}
	
    @Override
    public List<TourVO> cartList(String userid) throws Exception {
        return tourDAO.cartList(userid);
    }
    
    public void delTourCart(String reservno) {
        tourDAO.delTourCart(reservno);
    }
}
