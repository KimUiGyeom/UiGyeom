package com.project.crx;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.data.jpa.repository.config.EnableJpaAuditing;

@EnableJpaAuditing
@SpringBootApplication
public class CrxApplication {

	public static void main(String[] args) {
		SpringApplication.run(CrxApplication.class, args);
	}

}
