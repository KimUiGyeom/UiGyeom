package com.project.crx;

import java.util.ArrayList;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import jakarta.servlet.http.HttpSession;

@Controller
public class KakaoController {

	private static final Logger logger = LoggerFactory.getLogger(KakaoController.class);

	@Autowired
	private KakaoService kakaoService;

	@Autowired
	private UserService userService;

	@GetMapping("kakaoTerms")
	public String kakaoConnect() {
		StringBuffer url = new StringBuffer();
		url.append("https://kauth.kakao.com/oauth/authorize?");
		url.append("client_id=b40dbabe21f0e38eb1ca7cc8451a819c"); // 실제 클라이언트 아이디로 변경
		url.append("&redirect_uri=http://localhost:8080/kakaologin.do"); // 리디렉션 URI 설정
		url.append("&response_type=code");
		url.append("&prompt=login");

		return "redirect:" + url.toString();
	}

	@RequestMapping(value = "/kakaologin.do")
	public String kakaoLogin(@RequestParam("code") String code, Model model, HttpSession session) throws Exception {
		// code로 토큰 받음
		String accessToken = kakaoService.getToken(code);

		// 토큰으로 사용자 정보 담은 list 가져오기
		ArrayList<Object> list = kakaoService.getUserInfo(accessToken);

		// 사용자 정보를 세션에 저장
		String usermail = (String) list.get(0);
		String username = (String) list.get(1);

		session.setAttribute("usermail", usermail);
		session.setAttribute("username", username);
		session.setAttribute("isLogOn", true);

		// 사용자 정보가 데이터베이스에 있는지 확인하고, 없으면 새로 생성
		User user = userService.findByUsermail(usermail);
		if (user == null) {
			// 비밀번호가 null인 상태로 사용자 생성
			//user = new User(usermail, username, (String) list.get(2), (String) list.get(3), (String) list.get(4), null);
			user = new User();
			userService.saveUser(user);
		}

		// userid 값을 세션에 저장
		session.setAttribute("userid", user.getUserid());

		// 사용자의 비밀번호가 설정되어 있는지 확인
		if (user.getUserpwd() == null || user.getUserpwd().trim().isEmpty()) {
			// 비밀번호 설정 페이지로 리디렉션
			return "kakaologin";
		} else {
			// 메인 페이지로 리디렉션
			return "main";
		}
	}

	@RequestMapping("/setPassword.do")
	public String setPassword(@RequestParam("password") String password, @RequestParam("usermail") String usermail) {
		if (usermail != null && password != null && !password.isEmpty()) {
			User user = userService.findByUsermail(usermail);
			if (user != null) {
				user.setUserpwd(password); // 비밀번호 설정
				userService.updatePwdByMail(user); // 비밀번호 업데이트
			}
		}

		return "main"; // 비밀번호 설정 후 메인 페이지로 리디렉션
	}
}