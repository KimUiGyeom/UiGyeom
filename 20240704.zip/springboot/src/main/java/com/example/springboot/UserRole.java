package com.example.springboot;

public class UserRole {

}
