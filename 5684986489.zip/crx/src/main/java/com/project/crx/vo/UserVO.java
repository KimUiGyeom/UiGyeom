package com.project.crx.vo;

public class UserVO {

}
