package com.project.crx.service;

import org.springframework.stereotype.Service;
import org.springframework.beans.factory.annotation.Autowired;

import com.project.crx.dao.CrxDAO;
import com.project.crx.vo.CrxVO;

@Service
public class CrxServiceImpl implements CrxService {

	@Autowired
	private CrxDAO crxDAO;

    @Override
    public CrxVO login(CrxVO crxVO) throws Exception {
        CrxVO loginUser = null;
        try {
            // user 테이블에서 로그인 시도
            loginUser = crxDAO.userLogin(crxVO);
            if (loginUser != null && "user".equals(loginUser.getLevel())) {
                return loginUser;
            } else {
                // member 테이블에서 로그인 시도
                loginUser = crxDAO.memberLogin(crxVO);
                if (loginUser != null) {
                } else {
                    System.out.println("회원번호 또는 비밀번호가 일치하지 않습니다.");
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            System.out.println("Exception occurred during login: " + e.getMessage());
        }
        return loginUser;
    }

	@Override
	public CrxVO userInfo(int userid) {
		return crxDAO.userInfo(userid);
	}

	@Override
	public CrxVO userInfoEmail(String usermail) {
		return crxDAO.userInfoEmail(usermail);
	}

    @Override
    public void updateUserInfo(CrxVO crxVO) {
        crxDAO.updateUserInfo(crxVO);
    }

    @Override
    public void updateMemberInfo(CrxVO crxVO) {
        crxDAO.updateMemberInfo(crxVO);
    }

	// 일반 사용자의 비밀번호 변경
	@Override
	public void updatePwdId(CrxVO crxVO) {
		crxDAO.updatePwdId(crxVO);
	}
	
	@Override
	public void updatePwdMem(CrxVO crxVO) {
		crxDAO.updatePwdMem(crxVO);
	}

	// 카카오 로그인 사용자의 비밀번호 초기 설정
	@Override
	public void updatePwdMail(CrxVO crxVO) {
		crxDAO.updatePwdMail(crxVO);
	}
}