package com.project.crx.vo;

import org.springframework.stereotype.Component;

@Component("InfoVO")
public class InfoVO {
    
    private String trainApply_num;  // 승차권 번호(train)
    private int totalCharge;     	// 환불 예정 금액2 (train)
    
    private int tourApply_num;    	// 승차권 번호(tour)
    private int coin;    	        // 환불 예정 금액1 (tour)
	
    public String getTrainApply_num() {
		return trainApply_num;
	}
	public void setTrainApply_num(String trainApply_num) {
		this.trainApply_num = trainApply_num;
	}
	public int getTotalCharge() {
		return totalCharge;
	}
	public void setTotalCharge(int totalCharge) {
		this.totalCharge = totalCharge;
	}
	public int getTourApply_num() {
		return tourApply_num;
	}
	public void setTourApply_num(int tourApply_num) {
		this.tourApply_num = tourApply_num;
	}
	public int getCoin() {
		return coin;
	}
	public void setCoin(int coin) {
		this.coin = coin;
	}
}
