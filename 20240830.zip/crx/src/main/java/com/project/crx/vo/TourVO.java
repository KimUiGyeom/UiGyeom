package com.project.crx.vo;

import java.sql.Date;
import java.sql.Time;

public class TourVO {
	// tour 테이블 필드
	private String tournum;
	private String tourname;
	private String tourno;
	private String tourcoin;
	private String tourtitle;
	private String tourcomment;
	private String tourcontent;
	private String tourcost;
	private String tournoted;
	private String file1;
	private String file2;
	private String file3;
	private int reservno;	
	private int tourcount;
	private String tourdate;
	private String totalcoin;
	private int userid;
	
	// tourPay 테이블 필드
	private String imp_uid;
	private String merchant_uid;
	private int paid_amount;
	private int apply_num;
	private String username;
	private Date tourdatepay;
	private int count;
	private int coin;
	private String paytime;
	
	private String trainType;
	private String seatType;
	private Date startdate;
	private Time depTime;
	private Time arrTime;
	private String startname;
	private String endname;
	private String trainno;
	private int personnelCount;
	private int childCount;
	private String selectedSeats;
	private int totalCharge;
	private int endCharge;
	private String refund;
	
	
	private String duration;
	private String hocha; 
    private int totalAdultCharge;	//성인요금
    private int totalChildCharge;	//아동요금
    private int totalDiscount;		//할인요금

	public int getTotalAdultCharge() {
		return totalAdultCharge;
	}
	public void setTotalAdultCharge(int totalAdultCharge) {
		this.totalAdultCharge = totalAdultCharge;
	}
	public int getTotalChildCharge() {
		return totalChildCharge;
	}
	public void setTotalChildCharge(int totalChildCharge) {
		this.totalChildCharge = totalChildCharge;
	}
	public int getTotalDiscount() {
		return totalDiscount;
	}
	public void setTotalDiscount(int totalDiscount) {
		this.totalDiscount = totalDiscount;
	}
	public String getHocha() {
		return hocha;
	}
	public void setHocha(String hocha) {
		this.hocha = hocha;
	}
	public String getDuration() {
		return duration;
	}
	public void setDuration(String duration) {
		this.duration = duration;
	}
	public String getTournum() {
		return tournum;
	}
	public void setTournum(String tournum) {
		this.tournum = tournum;
	}
	public String getTourname() {
		return tourname;
	}
	public void setTourname(String tourname) {
		this.tourname = tourname;
	}
	public String getTourno() {
		return tourno;
	}
	public void setTourno(String tourno) {
		this.tourno = tourno;
	}
	public String getTourcoin() {
		return tourcoin;
	}
	public void setTourcoin(String tourcoin) {
		this.tourcoin = tourcoin;
	}
	public String getTourtitle() {
		return tourtitle;
	}
	public void setTourtitle(String tourtitle) {
		this.tourtitle = tourtitle;
	}
	public String getTourcomment() {
		return tourcomment;
	}
	public void setTourcomment(String tourcomment) {
		this.tourcomment = tourcomment;
	}
	public String getTourcontent() {
		return tourcontent;
	}
	public void setTourcontent(String tourcontent) {
		this.tourcontent = tourcontent;
	}
	public String getTourcost() {
		return tourcost;
	}
	public void setTourcost(String tourcost) {
		this.tourcost = tourcost;
	}
	public String getTournoted() {
		return tournoted;
	}
	public void setTournoted(String tournoted) {
		this.tournoted = tournoted;
	}
	public String getFile1() {
		return file1;
	}
	public void setFile1(String file1) {
		this.file1 = file1;
	}
	public String getFile2() {
		return file2;
	}
	public void setFile2(String file2) {
		this.file2 = file2;
	}
	public String getFile3() {
		return file3;
	}
	public void setFile3(String file3) {
		this.file3 = file3;
	}
	public int getReservno() {
		return reservno;
	}
	public void setReservno(int reservno) {
		this.reservno = reservno;
	}
	public int getTourcount() {
		return tourcount;
	}
	public void setTourcount(int tourcount) {
		this.tourcount = tourcount;
	}
	public String getTourdate() {
		return tourdate;
	}
	public void setTourdate(String tourdate) {
		this.tourdate = tourdate;
	}
	public String getTotalcoin() {
		return totalcoin;
	}
	public void setTotalcoin(String totalcoin) {
		this.totalcoin = totalcoin;
	}

	public int getUserid() {
		return userid;
	}
	public void setUserid(int userid) {
		this.userid = userid;
	}
	public String getImp_uid() {
		return imp_uid;
	}
	public void setImp_uid(String imp_uid) {
		this.imp_uid = imp_uid;
	}
	public String getMerchant_uid() {
		return merchant_uid;
	}
	public void setMerchant_uid(String merchant_uid) {
		this.merchant_uid = merchant_uid;
	}
	public int getPaid_amount() {
		return paid_amount;
	}
	public void setPaid_amount(int paid_amount) {
		this.paid_amount = paid_amount;
	}
	public int getApply_num() {
		return apply_num;
	}
	public void setApply_num(int apply_num) {
		this.apply_num = apply_num;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}

	public Date getTourdatepay() {
		return tourdatepay;
	}
	public void setTourdatepay(Date tourdatepay) {
		this.tourdatepay = tourdatepay;
	}
	public int getCount() {
		return count;
	}
	public void setCount(int count) {
		this.count = count;
	}
	public int getCoin() {
		return coin;
	}
	public void setCoin(int coin) {
		this.coin = coin;
	}
	public String getPaytime() {
		return paytime;
	}
	public void setPaytime(String paytime) {
		this.paytime = paytime;
	}
	public String getTrainType() {
		return trainType;
	}
	public void setTrainType(String trainType) {
		this.trainType = trainType;
	}
	public String getSeatType() {
		return seatType;
	}
	public void setSeatType(String seatType) {
		this.seatType = seatType;
	}
	public Date getStartdate() {
		return startdate;
	}
	public void setStartdate(Date startdate) {
		this.startdate = startdate;
	}
	public Time getDepTime() {
		return depTime;
	}
	public void setDepTime(Time depTime) {
		this.depTime = depTime;
	}
	public Time getArrTime() {
		return arrTime;
	}
	public void setArrTime(Time arrTime) {
		this.arrTime = arrTime;
	}
	public String getStartname() {
		return startname;
	}
	public void setStartname(String startname) {
		this.startname = startname;
	}
	public String getEndname() {
		return endname;
	}
	public void setEndname(String endname) {
		this.endname = endname;
	}
	public String getTrainno() {
		return trainno;
	}
	public void setTrainno(String trainno) {
		this.trainno = trainno;
	}
	public int getPersonnelCount() {
		return personnelCount;
	}
	public void setPersonnelCount(int personnelCount) {
		this.personnelCount = personnelCount;
	}
	public int getChildCount() {
		return childCount;
	}
	public void setChildCount(int childCount) {
		this.childCount = childCount;
	}
	public String getSelectedSeats() {
		return selectedSeats;
	}
	public void setSelectedSeats(String selectedSeats) {
		this.selectedSeats = selectedSeats;
	}
	public int getTotalCharge() {
		return totalCharge;
	}
	public void setTotalCharge(int totalCharge) {
		this.totalCharge = totalCharge;
	}
	public int getEndCharge() {
		return endCharge;
	}
	public void setEndCharge(int endCharge) {
		this.endCharge = endCharge;
	}
	public String getRefund() {
		return refund;
	}
	public void setRefund(String refund) {
		this.refund = refund;
	}
	
}
