package com.project.crx;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class UserServiceImpl implements UserService {

	@Autowired
	private KakaoRepository userRepository;

	@Override
	public User findByUsermail(String usermail) {
		return userRepository.findById(usermail).orElse(null);
	}

	@Override
	public void saveUser(User user) {
		userRepository.save(user);
	}

	@Override
	public void updatePwdByMail(User user) {
		userRepository.save(user); // 비밀번호 업데이트 (JPA에서는 save 메소드로 업데이트 가능)
	}
}