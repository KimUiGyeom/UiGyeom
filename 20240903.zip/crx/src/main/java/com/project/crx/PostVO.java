package com.project.crx;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Transient;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.springframework.web.multipart.MultipartFile;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Entity(name = "tour")
public class PostVO {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int tournum;
	
    @Column(columnDefinition = "LONGTEXT")
    private String tourname;

    @Column
    private String tourno;

    @Column
    private String tourcoin;
    
    @Column
    private String tourtitle;

    @Column(columnDefinition = "LONGTEXT")
    private String tourcomment;

    @Column(columnDefinition = "LONGTEXT")
    private String tourcontent;

    @Column(columnDefinition = "LONGTEXT")
    private String tourcost;

    @Column(columnDefinition = "LONGTEXT")
    private String tournoted;

    @Transient
    private MultipartFile file1Multipart;

    @Transient
    private MultipartFile file2Multipart;

    @Transient
    private MultipartFile file3Multipart;

    @Column
    private String file1;

    @Column
    private String file2;

    @Column
    private String file3;

    @Transient
    private String existingFile1;

    @Transient
    private String existingFile2;

    @Transient
    private String existingFile3;

    @Transient
    private String deleteFile1;

    @Transient
    private String deleteFile2;

    @Transient
    private String deleteFile3;
}
