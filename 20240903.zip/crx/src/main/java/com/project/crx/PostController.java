package com.project.crx;

import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import jakarta.servlet.http.HttpServletRequest;

@Controller
@RequestMapping("/smarteditor")
public class PostController {

    @Autowired
    private PostService postService;

    @PostMapping("/savePost")
    public ModelAndView savePost(HttpServletRequest req, PostVO post, ModelMap model) throws Exception {
        handleFileUpload(post);
        postService.savePost(post);
        model.addAttribute("result", HttpStatus.OK);
        return new ModelAndView("redirect:/tourList.do");
    }

    private String saveFile(MultipartFile file) throws Exception {
        String uploadDir = "src/main/webapp/img/"; // 업로드할 디렉토리
        Path uploadPath = Paths.get(uploadDir);

        // 디렉토리가 존재하지 않으면 생성
        if (!Files.exists(uploadPath)) {
            Files.createDirectories(uploadPath);
        }

        Path filePath = uploadPath.resolve(file.getOriginalFilename());
        Files.copy(file.getInputStream(), filePath);
        return filePath.toString();
    }

    @PostMapping("/updatePost")
    public ModelAndView updatePost(HttpServletRequest req, PostVO post, ModelMap model) throws Exception {
        handleFileUpload(post);
        postService.updatePost(post);
        model.addAttribute("result", HttpStatus.OK);
        long tournum = post.getTournum();
        String index = req.getParameter("index");
        return new ModelAndView("redirect:/tourDetail.do?tournum=" + tournum + "&index=" + index);
    }

    private void handleFileUpload(PostVO post) throws Exception {
        // 파일1 처리
        if ("true".equals(post.getDeleteFile1())) {
            post.setFile1(null);
        } else if (post.getFile1Multipart() != null && !post.getFile1Multipart().isEmpty()) {
            String filePath = saveFile(post.getFile1Multipart());
            post.setFile1(filePath);
        } else {
            post.setFile1(post.getExistingFile1());
        }

        // 파일2 처리
        if ("true".equals(post.getDeleteFile2())) {
            post.setFile2(null);
        } else if (post.getFile2Multipart() != null && !post.getFile2Multipart().isEmpty()) {
            String filePath = saveFile(post.getFile2Multipart());
            post.setFile2(filePath);
        } else {
            post.setFile2(post.getExistingFile2());
        }

        // 파일3 처리
        if ("true".equals(post.getDeleteFile3())) {
            post.setFile3(null);
        } else if (post.getFile3Multipart() != null && !post.getFile3Multipart().isEmpty()) {
            String filePath = saveFile(post.getFile3Multipart());
            post.setFile3(filePath);
        } else {
            post.setFile3(post.getExistingFile3());
        }
    }
}
