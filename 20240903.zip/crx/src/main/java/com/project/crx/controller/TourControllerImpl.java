package com.project.crx.controller;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.project.crx.service.TourService;
import com.project.crx.vo.TourVO;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@Controller
public class TourControllerImpl implements TourController {

	@Autowired
	private TourService tourService;
	
	//지역상품 페이지
    @GetMapping("/localtour.do")
    public String localtour() {
        return "localtour"; 
    }
    
    //관광상품 리스트
    @GetMapping("/tourList.do")
    public ModelAndView tourList(HttpServletRequest request, HttpServletResponse response) throws Exception {
        List<TourVO> tourList = tourService.tourList();
        ModelAndView mav = new ModelAndView("tourList");
        mav.addObject("tourList", tourList);
        return mav;
    }
    
    //관광상품 등록페이지
    @GetMapping("/tourRegister.do")
    public ModelAndView tourRegisterForm() {
        ModelAndView mav = new ModelAndView("tourRegister");
        return mav;
    }
    
    //관광상품 상세페이지
    @GetMapping("/tourDetail.do")
    public ModelAndView tourDetail(@RequestParam("index") int index, HttpServletRequest request, HttpServletResponse response) throws Exception {
        List<TourVO> tourList = tourService.tourList();
        TourVO tour = tourList.get(index);

        ModelAndView mav = new ModelAndView("tourDetail");
        mav.addObject("tour", tour);
        return mav;
    }
    
    //관광상품 수정페이지
    @GetMapping("/tourMod.do")
    public ModelAndView tourDetail2(@RequestParam("index") int index, HttpServletRequest request, HttpServletResponse response) throws Exception {
        List<TourVO> tourList = tourService.tourList();
        TourVO tour = tourList.get(index);
        ModelAndView mav = new ModelAndView("tourMod");
        mav.addObject("tour", tour);
        return mav;
    }
    
    //관광상품 상세페이지에서 관광상품 삭제
    @Override
    @GetMapping("/tourDelete.do")
    public ModelAndView tourDelete(@RequestParam("tournum") String tourDelete, HttpServletRequest request, HttpServletResponse response) throws Exception {
        tourService.tourDelete(tourDelete);
        ModelAndView mav = new ModelAndView("redirect:/tourList.do");
        return mav;
    }
    
    //관광상품 장바구니 추가
    @Override
    @PostMapping("/tourReserv")
    public ModelAndView tourReserv(HttpServletRequest request, HttpServletResponse response, RedirectAttributes rAttr) throws Exception {
        ModelAndView mav = new ModelAndView();

        try {
            TourVO TourVO = new TourVO();
            TourVO.setTourtitle(request.getParameter("tourtitle"));
            TourVO.setTourno(request.getParameter("tourno"));
            TourVO.setTourname(request.getParameter("tourname"));
            TourVO.setTourcount(Integer.parseInt(request.getParameter("tourcount")));
            TourVO.setTourdate(request.getParameter("tourdate"));
            TourVO.setTotalcoin(request.getParameter("totalcoin"));
            TourVO.setUserid(Integer.parseInt(request.getParameter("userid")));

            tourService.tourReserv(TourVO);

            // 리다이렉트할 때 파라미터 추가
            rAttr.addAttribute("tournum", request.getParameter("tournum"));
            rAttr.addAttribute("index", request.getParameter("index"));
            rAttr.addAttribute("userid", request.getParameter("userid"));
            rAttr.addFlashAttribute("message", "장바구니에 추가되었습니다.");

            mav.setViewName("redirect:/tourDetail.do");
        } catch(Exception e) {
            e.printStackTrace();
            mav.addObject("message", "장바구니에 추가실패했습니다.");
            mav.setViewName("tourReserv");
        }
        return mav;
    }
    
	//장바구니 페이지(기차예매, 관광상품)
    @GetMapping("/cart.do")
    public ModelAndView cartList(@RequestParam("userid") String userid, HttpServletRequest request, HttpServletResponse response) throws Exception {
        List<TourVO> cartList = tourService.cartList(userid);
        List<TourVO> trainList = tourService.trainList(userid);
        ModelAndView mav = new ModelAndView("cart");
        mav.addObject("cartList", cartList);
        mav.addObject("trainList", trainList);
        mav.addObject("userid", userid);
        return mav;
    }
    
    //장바구니 관광상품 선택삭제
    @PostMapping("/delTourCart")
    public ModelAndView delTourCart(@RequestParam("selectTour") List<Integer> selectedReservations, @RequestParam("userid") int userid) throws Exception {
        
        if (selectedReservations != null) {
            for (Integer reservno : selectedReservations) {
                tourService.delTourCart(reservno);
            }
        }        
        return new ModelAndView("redirect:/cart.do?userid=" + userid);
    }
    
    //장바구니 기차예매 선택삭제
    @PostMapping("/delTrainCart")
    public ModelAndView delTrainCart(@RequestParam("selectTrain") List<Integer> selectedReservations, @RequestParam("userid") int userid) throws Exception {
        
        if (selectedReservations != null) {
            for (Integer reservno : selectedReservations) {
                tourService.delTrainCart(reservno);
            }
        }        
        return new ModelAndView("redirect:/cart.do?userid=" + userid);
    }
    
    //실시간 버스 페이지
    @GetMapping("/realBus.do")
    public String realBus() {
        return "realBus"; 
    }
    
    //실시간 버스 컨트롤러
    @RestController
    @RequestMapping("/api")
    public class BusStationController {

        private final String seoulApiKey = "48554f554e6368753130386943557277";  // 여기에 서울 API 키를 직접 입력

        @GetMapping("/bus-stations")
        public ResponseEntity<?> getBusStations() {
            try {
                String url = "http://openapi.seoul.go.kr:8088/" + seoulApiKey + "/json/StationLoc/1/1000/";
                RestTemplate restTemplate = new RestTemplate();
                ResponseEntity<String> response = restTemplate.getForEntity(url, String.class);
                return ResponseEntity.ok(response.getBody());
            } catch (Exception e) {
                e.printStackTrace();
                return ResponseEntity.status(500).body("Error fetching bus station data");
            }
        }
    }
    
    //관광상품 결제페이지
    @GetMapping("/payTour.do")
    public ModelAndView payTour(
            @RequestParam("selectTour") List<String> selectedTours, 
            @RequestParam("userid") String userid, 
            @RequestParam("totalAmount") int totalAmount) throws Exception {
        
        // 사용자 ID로 장바구니 목록 조회
        List<TourVO> cartList = tourService.cartList(userid);

        // 선택된 투어 항목만 필터링하여 새로운 리스트로 생성
        List<TourVO> selectedTourList = cartList.stream()
            .filter(tour -> selectedTours.contains(String.valueOf(tour.getReservno())))
            .collect(Collectors.toList());

        // ModelAndView 객체 생성 및 JSP에 데이터 전달
        ModelAndView mav = new ModelAndView("payTour");
        mav.addObject("selectedTours", selectedTourList); // 선택된 항목 리스트 추가
        mav.addObject("totalAmount", totalAmount); // 클라이언트에서 계산된 총 금액 전달
        return mav;
    }
    
    //관광상품 결제 DB저장
	@PostMapping("/payTourResult")
	@ResponseBody
	public String handlePaymentResult(
	        @RequestParam("reservno") int reservno,
	        @RequestParam("username") String username,
	        @RequestParam("tourname") String tourname,
	        @RequestParam("tourno") String tourno,
	        @RequestParam("tourdatepay") String tourdateStr, // 문자열로 받기
	        @RequestParam("count") int count,
	        @RequestParam("coin") int coin,
	        @RequestParam("imp_uid") String impUid,
	        @RequestParam("merchant_uid") String merchantUid,
	        @RequestParam("paid_amount") int paidAmount,
	        @RequestParam("apply_num") int applyNum,
	        @RequestParam("userid") int userid
	) {
	    try {
	        // 문자열을 java.util.Date로 변환
	        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
	        java.util.Date utilDate = sdf.parse(tourdateStr);

	        // java.util.Date를 java.sql.Date로 변환
	        java.sql.Date sqlDate = new java.sql.Date(utilDate.getTime());

	        // CrxVO 객체 생성 및 값 설정
	        TourVO paymentRecord = new TourVO();
	        paymentRecord.setReservno(reservno);
	        paymentRecord.setUsername(username);
	        paymentRecord.setTourname(tourname);
	        paymentRecord.setTourno(tourno);
	        paymentRecord.setTourdatepay(sqlDate); // 변환된 Date 객체 설정
	        paymentRecord.setCount(count);
	        paymentRecord.setCoin(coin);
	        paymentRecord.setImp_uid(impUid);
	        paymentRecord.setMerchant_uid(merchantUid);
	        paymentRecord.setPaid_amount(paidAmount);
	        paymentRecord.setApply_num(applyNum);
	        paymentRecord.setUserid(userid);

	        // 데이터베이스에 저장
	        boolean success = tourService.savePaymentRecord(paymentRecord);
	        return success ? "Success" : "Error";

	    } catch (ParseException e) {
	        e.printStackTrace();
	        return "Error";
	    }
	}
	
	//기차예매 결제페이지
    @GetMapping("/payTrain.do")
    public ModelAndView payTrain(
            @RequestParam("selectTrain") List<String> selectedTrains, 
            @RequestParam("userid") String userid, 
            @RequestParam("endCharge") int endCharge) throws Exception {
        
        // 사용자 ID로 장바구니 목록 조회
        List<TourVO> trainList = tourService.trainList(userid);

        // 선택된 투어 항목만 필터링하여 새로운 리스트로 생성
        List<TourVO> selectedTrainList = trainList.stream()
            .filter(train -> selectedTrains.contains(String.valueOf(train.getReservno())))
            .collect(Collectors.toList());

        // ModelAndView 객체 생성 및 JSP에 데이터 전달
        ModelAndView mav = new ModelAndView("payTrain");
        mav.addObject("selectedTrains", selectedTrainList); // 선택된 항목 리스트 추가
        mav.addObject("endCharge", endCharge); // 클라이언트에서 계산된 총 금액 전달
        return mav;
    }
    
    //결제완료시 장바구니 DB삭제(기차예매)
	@PostMapping("deltrainticket")
	@ResponseBody
	public String deltrainticket(@RequestParam("reservno") int reservno) {
	    try {
	        tourService.deltrainticket(reservno);
	        return "Success"; 
	    } catch (Exception e) {
	        return "Error";
	    }
	}
	
	//결제완료시 장바구니 DB삭제(관광상품)
	@PostMapping("deltourticket")
	@ResponseBody
	public String deltourticket(@RequestParam("reservno") int reservno) {
	    try {
	        tourService.deltourticket(reservno);
	        return "Success"; 
	    } catch (Exception e) {
	        return "Error";
	    }
	}	
	
	//발권관리 페이지(관광상품)
	@GetMapping("/tourTicketing.do")
	public ModelAndView tourTicketing(@RequestParam("apply_num") int apply_num) throws Exception {
	    List<TourVO> ticket = tourService.tourTicket(apply_num);

	    ModelAndView mav = new ModelAndView("tourTicketing");
	    mav.addObject("ticket", ticket);

	    return mav;
	}
	
	//예매관리 페이지(기차예매)
    @GetMapping("/mgmtTrain.do")
    public ModelAndView mgmtTrain(@RequestParam("userid") int userid, HttpServletRequest request, HttpServletResponse response) throws Exception {
        List<TourVO> mgmtTrain = tourService.mgmtTrain(userid);        
        ModelAndView mav = new ModelAndView("mgmtTrain");
        mav.addObject("mgmtTrain", mgmtTrain);
        return mav;
    }
    
    //예매관리 페이지(관광상품)
    @GetMapping("/mgmtTour.do")
    public ModelAndView mgmtTour(@RequestParam("userid") int userid, HttpServletRequest request, HttpServletResponse response) throws Exception {
        List<TourVO> mgmtTour = tourService.mgmtTour(userid);
        ModelAndView mav = new ModelAndView("mgmtTour");
        mav.addObject("mgmtTour", mgmtTour);
        return mav;
    }
    
    //환불페지(기차예매)
    @GetMapping("/refundTrain.do")
    public ModelAndView refundTrain(@RequestParam("apply_num") int apply_num, HttpServletRequest request, HttpServletResponse response) throws Exception {
        List<TourVO> refundTrain = tourService.refundTrain(apply_num);
        ModelAndView mav = new ModelAndView("refundTrain");
        mav.addObject("refundTrain", refundTrain);
        return mav;
    }
    
    //환불페이지(관광상품)
    @GetMapping("/refundTour.do")
    public ModelAndView refundTour(@RequestParam("apply_num") int apply_num, HttpServletRequest request, HttpServletResponse response) throws Exception {
        List<TourVO> refundTour = tourService.refundTour(apply_num);
        ModelAndView mav = new ModelAndView("refundTour");
        mav.addObject("refundTour", refundTour);
        return mav; 
    }
    
    //환불성공 DB업데이트(기차예매)
    @PostMapping("/refundUpTrain")
    public ResponseEntity<String> refundUpTrain(@RequestParam("apply_num") int apply_num) {
        try {
            tourService.refundUpTrain(apply_num);
            return ResponseEntity.ok("환불 성공");
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("환불 실패");
        }
    }
    
    //환불성공 DB업데이트(관광상품)
    @PostMapping("/refundUpTour")
    public ResponseEntity<String> refundUpTour(@RequestParam("apply_num") int apply_num) {
        try {
            tourService.refundUpTour(apply_num);
            return ResponseEntity.ok("환불 성공");
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("환불 실패");
        }
    }
    
    //이용내역 페이지(기차예매)
    @GetMapping("/usageTrain.do")
    public ModelAndView usageTrain(@RequestParam("userid") int userid, HttpServletRequest request, HttpServletResponse response) throws Exception {
        List<TourVO> usageTrain = tourService.usageTrain(userid);
        ModelAndView mav = new ModelAndView("usageTrain");
        mav.addObject("usageTrain", usageTrain);
        return mav;
    }
    
    //이용내역 페이지(관광상품)
    @GetMapping("/usageTour.do")
    public ModelAndView usageTour(@RequestParam("userid") int userid, HttpServletRequest request, HttpServletResponse response) throws Exception {
        List<TourVO> usageTour = tourService.usageTour(userid);
        ModelAndView mav = new ModelAndView("usageTour");
        mav.addObject("usageTour", usageTour);
        return mav;
    }
    
    //이용내역 페이지 기간검색(기차예매)
    @GetMapping("/trainSearch")
    public ModelAndView trainSearch(@RequestParam("userid") int userid, 
                                     @RequestParam("startDate") @DateTimeFormat(pattern = "yyyy-MM-dd") Date startDate,
                                     @RequestParam("endDate") @DateTimeFormat(pattern = "yyyy-MM-dd") Date endDate) throws Exception {
      
        List<TourVO> trainSearch = tourService.trainSearch(userid, startDate, endDate);       
        
        ModelAndView mav = new ModelAndView("usageTrain");
        mav.addObject("trainSearch", trainSearch);
        return mav;
    }
    
    //이용내역 페이지 기간검색(관광상품)
    @GetMapping("/tourSearch")
    public ModelAndView tourSearch(@RequestParam("userid") int userid, 
                                     @RequestParam("startDate") @DateTimeFormat(pattern = "yyyy-MM-dd") Date startDate,
                                     @RequestParam("endDate") @DateTimeFormat(pattern = "yyyy-MM-dd") Date endDate) throws Exception {
      
        List<TourVO> tourSearch = tourService.tourSearch(userid, startDate, endDate);       
        
        ModelAndView mav = new ModelAndView("usageTour");
        mav.addObject("tourSearch", tourSearch);
        return mav;
    }
}