package com.project.crx.service;

import java.util.List;

import com.project.crx.vo.TicketVO;

public interface TicketService {
    void saveReservation(TicketVO reservation) throws Exception;
	List<TicketVO> getPayment();
	boolean savePayment(TicketVO payment);
	List<TicketVO> getTicketing();
}
