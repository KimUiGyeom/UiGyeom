function validatetrainForm() {
    var checkboxes = document.getElementsByName("selectTrainTour");
    var isChecked = false;
    for (var i = 0; i < checkboxes.length; i++) {
        if (checkboxes[i].checked) {
            isChecked = true;
            break;
        }
    }

    if (!isChecked) {
        alert("삭제할 항목을 선택해 주세요.");
        return false;
    }

    return confirm("선택한 항목을 삭제하시겠습니까?");
}
	
function validatetourForm() {
    var checkboxes = document.getElementsByName("selectTour");
    var isChecked = false;
    for (var i = 0; i < checkboxes.length; i++) {
        if (checkboxes[i].checked) {
            isChecked = true;
            break;
        }
    }

    if (!isChecked) {
        alert("삭제할 항목을 선택해 주세요.");
        return false;
    }

    return confirm("선택한 항목을 삭제하시겠습니까?");
}

document.addEventListener('DOMContentLoaded', () => {
    const trainCheckboxes = document.querySelectorAll('.trainCheckbox');
    const tourCheckboxes = document.querySelectorAll('.tourCheckbox');
    const trainTotalAmountElement = document.getElementById('trainTotalAmount');
    const tourTotalAmountElement = document.getElementById('tourTotalAmount');
    const trainCheckoutButton = document.getElementById('trainCheckoutButton');
    const tourCheckoutButton = document.getElementById('tourCheckoutButton');
    const userIdElement = document.getElementById('userid');

    function updateTrainTotal() {
        let total = 0;
        trainCheckboxes.forEach(checkbox => {
            if (checkbox.checked) {
                const price = parseInt(checkbox.getAttribute('data-price'), 10);
                total += price;
            }
        });
        trainTotalAmountElement.textContent = `${total.toLocaleString('ko-KR')}`;
        return total; // 총금액 반환
    }

    function updateTourTotal() {
        let total = 0;
        tourCheckboxes.forEach(checkbox => {
            if (checkbox.checked) {
                const price = parseInt(checkbox.getAttribute('data-price'), 10);
                total += price;
            }
        });
        tourTotalAmountElement.textContent = `${total.toLocaleString('ko-KR')}`;
        return total; // 총금액 반환
    }

    function validateTrainSelection() {
        const selectedTrains = [];
        let totalAmount = 0;

        trainCheckboxes.forEach(checkbox => {
            if (checkbox.checked) {
                selectedTrains.push(checkbox.value);
                totalAmount += parseInt(checkbox.getAttribute('data-price'), 10);
            }
        });

        if (selectedTrains.length > 0) {
            alert('결제 페이지로 이동합니다.');
            const userId = userIdElement.value;
            const selectedTrainsParam = selectedTrains.join(',');
            window.location.href = `tourPay.do?userid=${userId}&selectTour=${selectedTrainsParam}&totalAmount=${totalAmount}`;
        } else {
            alert('선택된 상품이 없습니다. 결제할 상품을 선택해 주세요.');
        }
    }

    function validateTourSelection() {
        const selectedTours = [];
        let totalAmount = 0;

        tourCheckboxes.forEach(checkbox => {
            if (checkbox.checked) {
                selectedTours.push(checkbox.value);
                totalAmount += parseInt(checkbox.getAttribute('data-price'), 10);
            }
        });

        if (selectedTours.length > 0) {
            alert('결제 페이지로 이동합니다.');
            const userId = userIdElement.value;
            const selectedToursParam = selectedTours.join(',');
            window.location.href = `tourPay.do?userid=${userId}&selectTour=${selectedToursParam}&totalAmount=${totalAmount}`;
        } else {
            alert('선택된 상품이 없습니다. 결제할 상품을 선택해 주세요.');
        }
    }

    trainCheckboxes.forEach(checkbox => {
        checkbox.addEventListener('change', updateTrainTotal);
    });

    tourCheckboxes.forEach(checkbox => {
        checkbox.addEventListener('change', updateTourTotal);
    });

    trainCheckoutButton.addEventListener('click', validateTrainSelection);
    tourCheckoutButton.addEventListener('click', validateTourSelection);
});